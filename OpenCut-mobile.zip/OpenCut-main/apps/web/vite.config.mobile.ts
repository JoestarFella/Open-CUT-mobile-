import { defineConfig } from 'vite'
import { tanstackStart } from '@tanstack/react-start/plugin/vite'
import viteReact from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// Build estático (SPA) para empacotar dentro do app Android (Capacitor).
// Sem plugin do Cloudflare e sem devtools. Saída: dist/client/index.html
export default defineConfig({
  resolve: { tsconfigPaths: true },
  plugins: [
    tailwindcss(),
    tanstackStart({
      spa: {
        enabled: true,
        prerender: { outputPath: '/index', crawlLinks: false },
      },
    }),
    viteReact(),
  ],
})
