package app.opencut.mobile;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
