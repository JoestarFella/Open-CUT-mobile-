import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'app.opencut.mobile',
  appName: 'OpenCut',
  // Saída do build SPA do apps/web (vite.config.mobile.ts)
  webDir: '../web/dist/client',
  backgroundColor: '#000000',
  android: {
    allowMixedContent: false,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 0,
      backgroundColor: '#000000',
    },
    StatusBar: {
      style: 'DARK',
      backgroundColor: '#000000',
    },
  },
}

export default config
