# OpenCut Mobile (Android / APK)

Empacota o `apps/web` como app Android usando [Capacitor](https://capacitorjs.com).
O web app é compilado em modo SPA estático (`apps/web/vite.config.mobile.ts`) e
copiado para dentro do APK, então o app funciona offline.

## Gerar o APK pelo GitHub

1. Suba o repositório no GitHub.
2. Vá em **Actions → Build Android APK → Run workflow** (ou faça push na `main`).
3. Ao terminar, baixe o APK em **Artifacts → OpenCut-apk**.
   Em tags `v*` (ex.: `v0.0.1`) o APK também é anexado em **Releases**.

O APK gerado é *debug* (assinado com a chave de debug) e instala direto no celular
(ative "instalar apps de fontes desconhecidas").

## Gerar localmente

Requisitos: bun, Node 22, JDK 21 e Android SDK.

```sh
cd apps/web && bun install
cd ../mobile && bun install
bun run build            # build web SPA + cap sync android
cd android && ./gradlew assembleDebug
# APK: android/app/build/outputs/apk/debug/app-debug.apk
```

Ou abra no Android Studio: `bun run open`.

## Notas

- `appId`: `app.opencut.mobile` (mude em `capacitor.config.ts` e rode `bunx cap sync`).
- A fonte Playfair Display é carregada do Google Fonts; offline cai na fonte padrão.
